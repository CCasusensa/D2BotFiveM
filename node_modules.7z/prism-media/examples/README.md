## Examples

Examples are also available within the [official documentation](https://hydrabolt.me/prism-media/?api) and they
may be more useful than the examples listed here if you're looking for how to use a single feature.
