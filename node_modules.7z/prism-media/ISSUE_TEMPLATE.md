#### Issue:
<!-- please try to be as descriptive as possible, posting stack traces if possible! -->

#### Steps to reproduce:
<!-- please try to ensure the issue can be reproduced if possible, it makes debugging much easier! -->

#### Further details:
- Operating System:
- Node.js version:
- Commit I'm using:
