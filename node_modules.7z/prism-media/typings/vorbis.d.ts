import { Transform } from 'stream';

export namespace vorbis {
  export class WebmDemuxer extends Transform {}
}