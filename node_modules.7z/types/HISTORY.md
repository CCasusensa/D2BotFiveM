0.1.1 / 2012-09-17

* Added SortedList#concat(otherList) that produces merged copy.


0.1.0 / 2012-05-15
------------------

* Added Hash and Set structures


0.0.1 / 2012-02-09
------------------

* First public release
