module.exports = require('./lib/types');
