* [[`e073a72`](https://github.com/devsnek/snekfetch/commit/e073a720678fa6eb9269ea4310bf4189e992c3d8)] - [version] 4.0.4
* [[`0e603fa`](https://github.com/devsnek/snekfetch/commit/0e603fa740e9482cafdef4f34072306f61f1c1ba)] - [browser] fix webpack output
* [[`2d8cd56`](https://github.com/devsnek/snekfetch/commit/2d8cd56d65befdb693a03e0e9746cdb5e2aa2dcd)] - [changelog] update
* [[`26182ff`](https://github.com/devsnek/snekfetch/commit/26182ff9ab32ba787335df55557441aa266c7bf7)] - [version] 4.0.3
* [[`9fef333`](https://github.com/devsnek/snekfetch/commit/9fef33367056c5e7b9f999ee407817a5a1d8765a)] - add script to package to generate changelog
* [[`08ad9f6`](https://github.com/devsnek/snekfetch/commit/08ad9f6936203c5b86cc84659d91c91b9d1d3206)] - cut older commits from changelog
* [[`75cd455`](https://github.com/devsnek/snekfetch/commit/75cd455353d50b9bfa643f1e0aed249b68d2e83f)] - change changelog format
* [[`0cb076b`](https://github.com/devsnek/snekfetch/commit/0cb076b81e8c3c948602d5b681636e9e23be70e9)] - things i said i would do
* [[`9222cbe`](https://github.com/devsnek/snekfetch/commit/9222cbe2f055335c5f173c050e43e07dd5f906f8)] - 4.0.2
* [[`b9d53f5`](https://github.com/devsnek/snekfetch/commit/b9d53f555599e471eb29a5e033fb22d946600d6b)] - status is now statusCode (#41)
* [[`32c5da6`](https://github.com/devsnek/snekfetch/commit/32c5da60a2c0401ee6b66cc4a5caa86c3aa20ec8)] - 4.0.1
* [[`d925b7a`](https://github.com/devsnek/snekfetch/commit/d925b7a506d99633d941628fd0a6dd3f8d38a453)] - add repo token
* [[`aaa505a`](https://github.com/devsnek/snekfetch/commit/aaa505adfcb5c2622eed8b6d78a3b74d159a0e26)] - change badge
* [[`7ca062d`](https://github.com/devsnek/snekfetch/commit/7ca062d3bd70ebd292a2c0e230b894e933e96a9b)] - use string concat for speeeeeed
* [[`8fb6c5c`](https://github.com/devsnek/snekfetch/commit/8fb6c5c42963cc36606635807bcfda14b274cef6)] - cleanup
* [[`f22d100`](https://github.com/devsnek/snekfetch/commit/f22d100724d9156cfe2658aac976d4663d39b7d0)] - catch stream errors
* [[`834d3ab`](https://github.com/devsnek/snekfetch/commit/834d3ab39edfb1cfe9de57949f4f0ad430117b43)] - version 4 yo
* [[`9b2cfcd`](https://github.com/devsnek/snekfetch/commit/9b2cfcd1b101dd63c1cbc716ccd0dd01a78cffc5)] - add node 10
* [[`7554922`](https://github.com/devsnek/snekfetch/commit/75549220a44e03d889034b24ff5a4385ed7d52f5)] - update eslint
* [[`7770ae9`](https://github.com/devsnek/snekfetch/commit/7770ae911fad92863ca1ed4f73eca9baff03d9f1)] - fix github link in docs
* [[`907319b`](https://github.com/devsnek/snekfetch/commit/907319b9b907f5fae73c8277f5447345e84bdf82)] - fix version badge
* [[`62d3574`](https://github.com/devsnek/snekfetch/commit/62d35745cb7ed480a39fa80a7dfd15f352ffddab)] - remove object spread
* [[`b69ecfb`](https://github.com/devsnek/snekfetch/commit/b69ecfbe916df673bb32c601484b75a1f20654ad)] - http2 on 9.8.0
* [[`4250ab6`](https://github.com/devsnek/snekfetch/commit/4250ab6970ad4b5e2963a2f71f489ebe2996a970)] - buffers for everyone yay
* [[`a49b282`](https://github.com/devsnek/snekfetch/commit/a49b2828dc6188ee9d214cad5d2ca673ef5888c8)] - avoid scaring users
* [[`4157fa2`](https://github.com/devsnek/snekfetch/commit/4157fa21644aea746181ae6cab4f9da6d223b602)] - agh
* [[`57b4e67`](https://github.com/devsnek/snekfetch/commit/57b4e674157760a2de56b1108590fdc0c2326e55)] - bump version
* [[`6054801`](https://github.com/devsnek/snekfetch/commit/6054801e56ae7e06bb02dd6466474b3600bfea91)] - lock http2 to node >= 10
* [[`8dc7321`](https://github.com/devsnek/snekfetch/commit/8dc732119e726aab2466a0df69597143455d6cb1)] - fix regression with static methods
* [[`5948edd`](https://github.com/devsnek/snekfetch/commit/5948edd824388d4e2b88b85caf9619e6c64ed56c)] - fall back to destroying http2 connection
* [[`d321cfe`](https://github.com/devsnek/snekfetch/commit/d321cfecd630d6323e8143278528fca0a28fd7ef)] - many bugg fixx
* [[`3baaa7d`](https://github.com/devsnek/snekfetch/commit/3baaa7d3d75c50d881285e63432beedb8ec12698)] - clean up errors and thing
* [[`2cff41d`](https://github.com/devsnek/snekfetch/commit/2cff41d34e9ca1a08ecb40a8615aa0b38f0d96ff)] - Update ISSUE_TEMPLATE.md
* [[`daac3ce`](https://github.com/devsnek/snekfetch/commit/daac3ce57f7775f29412fcc5619e1a39138b5415)] - update travis node
* [[`6373531`](https://github.com/devsnek/snekfetch/commit/6373531976811b9e0509155cfe7b4ca2723cc01e)] - remove .eslintcache
* [[`914ab80`](https://github.com/devsnek/snekfetch/commit/914ab802dd9a7d2b39646129d530a2448a515b13)] - clean up
* [[`aff503a`](https://github.com/devsnek/snekfetch/commit/aff503aa616d00bc469c18e6fb87eb88d5e78864)] - update readme
* [[`3b0b531`](https://github.com/devsnek/snekfetch/commit/3b0b5317b29cc363f5b7fd9babbf7790442935be)] - reuse connection and close connection
* [[`1032a5b`](https://github.com/devsnek/snekfetch/commit/1032a5b812417acf6d258f08b4adab0e9be45308)] - update docs and such
* [[`98cba31`](https://github.com/devsnek/snekfetch/commit/98cba3127ddb1eab5b80f688e6be6d2cf0cf46d4)] - fix browser build
* [[`a281002`](https://github.com/devsnek/snekfetch/commit/a2810020191a309d505bb612b5a7833d3337f4e7)] - http2 rewrite
* [[`51d6568`](https://github.com/devsnek/snekfetch/commit/51d6568a5f724bc8916c845049930e4c049475f7)] - move around esm
* [[`c939e4f`](https://github.com/devsnek/snekfetch/commit/c939e4fd5af8391dd4ebc627200698c739689519)] - version 4
* [[`eb86f67`](https://github.com/devsnek/snekfetch/commit/eb86f67aac211a05147ae4058d0280f9f37df66f)] - clean up mocks and do some golf
* [[`6b3f822`](https://github.com/devsnek/snekfetch/commit/6b3f82254491b6e30b9fa1b86cb3ffd3c0a2fa42)] - add tests for qs_mock
* [[`25f0f86`](https://github.com/devsnek/snekfetch/commit/25f0f865ec6d63a2a71bd8941d90cfd5b574340c)] - bump version
* [[`591fe30`](https://github.com/devsnek/snekfetch/commit/591fe305b7f99b17683fc44ee8c9078ed244a38a)] - Merge branch 'master' of https://github.com/devsnek/snekfetch
* [[`c4c7816`](https://github.com/devsnek/snekfetch/commit/c4c7816e77ffd2fa496ff86e78e86d47bf9f3635)] - many fixes
* [[`359c2dc`](https://github.com/devsnek/snekfetch/commit/359c2dc1d078154e6478978cb27bfa9fe12e7b4d)] - fix tests
* [[`0934d09`](https://github.com/devsnek/snekfetch/commit/0934d0967113241d06c109a44ba0a885b5546414)] - bump version
* [[`92e76ef`](https://github.com/devsnek/snekfetch/commit/92e76efc21f0d37f3a08246274ffca84c57ce1f1)] - move default user agent to node
* [[`f85d9d6`](https://github.com/devsnek/snekfetch/commit/f85d9d66f29030d33bec485715943588874c7337)] - stuff
* [[`f41be40`](https://github.com/devsnek/snekfetch/commit/f41be400b0fe6ff4db5e30fe3327080eeafe5618)] - update dep badge
* [[`aa79d40`](https://github.com/devsnek/snekfetch/commit/aa79d40045f7c609a2972f4c8e5eaa7f5b99fb12)] - eslint better
* [[`ac841a9`](https://github.com/devsnek/snekfetch/commit/ac841a9405292502aad905ec3c63ce28ddd82f24)] - bump version
* [[`f45a2ba`](https://github.com/devsnek/snekfetch/commit/f45a2ba57aaf022c70b237dcd79b86df9a764d5a)] - add jsdelivr entry to package.json
* [[`6612b18`](https://github.com/devsnek/snekfetch/commit/6612b18b3c6bab1adc4925d110745fc495e1e0b0)] - fix tests
* [[`014f4bd`](https://github.com/devsnek/snekfetch/commit/014f4bd1ad73254f69510d24290d549bd420e653)] - clean up
* [[`c0f1ee8`](https://github.com/devsnek/snekfetch/commit/c0f1ee8e5948df065815f87248a956feb1a47c34)] - bump version
* [[`6db72a4`](https://github.com/devsnek/snekfetch/commit/6db72a440b1450e789e5ed1b029ac51b075cfede)] - coverage
* [[`052f027`](https://github.com/devsnek/snekfetch/commit/052f02745afcf663530819c1fbb862ef56706f96)] - destroy response once we don't need it
* [[`8a1f0eb`](https://github.com/devsnek/snekfetch/commit/8a1f0eba16d852c76970e5001a053f85dcb9634d)] - clean up agents and redirects, handling body is more effecient now
* [[`8df39ad`](https://github.com/devsnek/snekfetch/commit/8df39ad5778798cadef99574dc7a17497ad580c2)] - clean up inheritence
* [[`30a7445`](https://github.com/devsnek/snekfetch/commit/30a7445ab7bf3c02f363bf0c44d1d6057c722de0)] - clean up tests
* [[`9d2479a`](https://github.com/devsnek/snekfetch/commit/9d2479a50784aee69a13a8537135a384d02e796e)] - update syncify dep
* [[`3574cb3`](https://github.com/devsnek/snekfetch/commit/3574cb3be69395b991d99ddc8704721260c7be8b)] - update syncify
* [[`eceedee`](https://github.com/devsnek/snekfetch/commit/eceedeec254e6b849d55c73572a8513bc6cc04a7)] - misc
* [[`a42ec62`](https://github.com/devsnek/snekfetch/commit/a42ec62d86d9c20adfe5678afc01ed486adeeb47)] - sync api
* [[`ea75c58`](https://github.com/devsnek/snekfetch/commit/ea75c587e6329abab233067303c934e0906f9842)] - new test setup
* [[`e12bbda`](https://github.com/devsnek/snekfetch/commit/e12bbda89b1effd3e60521149bcb1f0451f7fb4b)] - expand esm
* [[`d277881`](https://github.com/devsnek/snekfetch/commit/d27788129a25bb04b49bc83b27b84ae9c1e70d57)] - new eslint
* [[`f687e93`](https://github.com/devsnek/snekfetch/commit/f687e937b33a75bbcbdc4d8e20fe048e2f5a0297)] - clean snekfetch options docs
* [[`d142b32`](https://github.com/devsnek/snekfetch/commit/d142b321b085c7ccc3922d0aeb44951740afe170)] - make readme nicer
* [[`3130126`](https://github.com/devsnek/snekfetch/commit/3130126bac849d5813a8a2cfc3ebd928c1009e86)] - Create CONTRIBUTING.md
* [[`8078e14`](https://github.com/devsnek/snekfetch/commit/8078e14ee83f5d566d37f33151302699647c1911)] - github made me do this
* [[`8e42545`](https://github.com/devsnek/snekfetch/commit/8e42545a555c6023221a1a9de062815cb8cd1905)] - Create LICENSE
* [[`d69a3ce`](https://github.com/devsnek/snekfetch/commit/d69a3ce522ace5b37915ea2aef40589aacf36829)] - agh
* [[`437b9d7`](https://github.com/devsnek/snekfetch/commit/437b9d7e2811e8ad4110fc70aef13bff2ccc9f50)] - plz work
* [[`7f45688`](https://github.com/devsnek/snekfetch/commit/7f45688aa635c4581f68a484e8c805707de4ac71)] - fix stuff more
* [[`c6fedc2`](https://github.com/devsnek/snekfetch/commit/c6fedc25ff304ecec96c050423824b3d628488fb)] - more esm
* [[`13e8355`](https://github.com/devsnek/snekfetch/commit/13e8355233493f42277d9a8df802f4c678b65c89)] - fix
* [[`0ce04a1`](https://github.com/devsnek/snekfetch/commit/0ce04a166d0f8b75dd1605f8f2259e574882e45c)] - module, sonar
* [[`07e2984`](https://github.com/devsnek/snekfetch/commit/07e2984dfd0320260985885acfeb9936709b3b23)] - prepublish
* [[`1b42f5c`](https://github.com/devsnek/snekfetch/commit/1b42f5c644240e4028fe6dd7cba52b04cf6c058f)] - misc
* [[`1301576`](https://github.com/devsnek/snekfetch/commit/1301576da41266c342fec8e4db174d6131137e5e)] - add unpkg to package.json
* [[`06685fd`](https://github.com/devsnek/snekfetch/commit/06685fd019eaabd83a8cfad15feb30caade9badc)] - bump to 3.5.6
* [[`728085a`](https://github.com/devsnek/snekfetch/commit/728085a5e74213b82faeb763080c1fe03c652d41)] - use umd
* [[`dfe5121`](https://github.com/devsnek/snekfetch/commit/dfe5121834eb2b806feb5496beb5fbf6c5fa01df)] - whoops
* [[`6a404b6`](https://github.com/devsnek/snekfetch/commit/6a404b64fb7518c2d69764ee2f02ed649883b742)] - bump version
* [[`a22772d`](https://github.com/devsnek/snekfetch/commit/a22772d05ce687119d6028ddb7a6f6d3ae16153e)] - fix issue with default params
* [[`5dcb17d`](https://github.com/devsnek/snekfetch/commit/5dcb17d5a666a850a84e74171a7863eec0ce7392)] - stuff
* [[`7da75cf`](https://github.com/devsnek/snekfetch/commit/7da75cf2d21454824cdf803880f94c582ccdc6a7)] - add supplemental stuff for packages that want benefits of my rules
* [[`38558b4`](https://github.com/devsnek/snekfetch/commit/38558b4fecb546caa0d48eaa49a647b1cf3de442)] - try release with browser
* [[`9cbbb57`](https://github.com/devsnek/snekfetch/commit/9cbbb5742ece337d0b2f3d068736cffe607e3bd4)] - bump to 3.5.2
* [[`f7b4e10`](https://github.com/devsnek/snekfetch/commit/f7b4e10b0a2a23b4da81b6e0bd960a09ea8c4620)] - encoding
* [[`897f596`](https://github.com/devsnek/snekfetch/commit/897f596e03a61b7a162681e40e610c782426a963)] - add gzip test
* [[`d799b52`](https://github.com/devsnek/snekfetch/commit/d799b524152257f3835d713c11d8417d453715b7)] - move more node things out of index.js
* [[`201cd36`](https://github.com/devsnek/snekfetch/commit/201cd368b64e689d365e291d5a71789e1fb8909a)] - move node specific method out of index.js
* [[`e9a40dc`](https://github.com/devsnek/snekfetch/commit/e9a40dcb8143c4a42663c5cc487ad3737366dfab)] - clean up redirect header building
* [[`59b7e1b`](https://github.com/devsnek/snekfetch/commit/59b7e1b6ccf4c048691c7c9bc98a74ae9e79d74c)] - pass resolver/rejector to promise in then call
* [[`6b88278`](https://github.com/devsnek/snekfetch/commit/6b88278cd61a46e76164c447465a702351e912af)] - clean up
* [[`4fbff07`](https://github.com/devsnek/snekfetch/commit/4fbff07175f7f644b53815859d4c01db2df48e93)] - fix enormous bug where requests were fetched n+1 times for each call
* [[`4f89c02`](https://github.com/devsnek/snekfetch/commit/4f89c020a38aeaed3ff85f9b865dcb3fea5baae6)] - fix up markdown rendering
* [[`242cfea`](https://github.com/devsnek/snekfetch/commit/242cfea0fe06b5b48c5370acd51d263e6c2b115a)] - more scoping of agent key
* [[`9429fac`](https://github.com/devsnek/snekfetch/commit/9429facbd590b6325eeb3b0280326040fc1846d2)] - more standardization of test object
* [[`a0661e3`](https://github.com/devsnek/snekfetch/commit/a0661e368d819431722a17300c2eff545487e2cc)] - standardize test objects
* [[`f28879f`](https://github.com/devsnek/snekfetch/commit/f28879f84c7224c49df68c09a5f4ea9377ee2695)] - fuck you js strings rot in hell
* [[`95fa2ab`](https://github.com/devsnek/snekfetch/commit/95fa2abcdebd1e2c8294d80df0a624c2d5cd1e8d)] - more golf
* [[`492a04e`](https://github.com/devsnek/snekfetch/commit/492a04e6aa9c3e75daa1248cc5931947d0e4c550)] - add build link
* [[`3f2008a`](https://github.com/devsnek/snekfetch/commit/3f2008aeda01fb4ebc2f883eac03422d3463f816)] - no idea why this is so high
* [[`39ab0a4`](https://github.com/devsnek/snekfetch/commit/39ab0a451cdf228d29480c9ef3288bae0223866e)] - bump version hype
* [[`ec20c02`](https://github.com/devsnek/snekfetch/commit/ec20c02c15999ef67fa956f44c04d6e3eade77c1)] - playing code golf
* [[`ee6ef49`](https://github.com/devsnek/snekfetch/commit/ee6ef49a91ed314d5859f8c53a9e4fd457e7027c)] - new qs mock for increased tinyness
* [[`1854e6a`](https://github.com/devsnek/snekfetch/commit/1854e6aaf651e196e6d41493b426b1cb19889883)] - entries bug is only in latest npm release
* [[`a07755e`](https://github.com/devsnek/snekfetch/commit/a07755e2133121b866b4d2504a29a65d3f499389)] - fix lint
* [[`ac69061`](https://github.com/devsnek/snekfetch/commit/ac6906171fd43b492a184c2d540f2113b28d2778)] - increase coverage
* [[`58ca5a4`](https://github.com/devsnek/snekfetch/commit/58ca5a49ee4465702704c33380eabf2114cc4d44)] - [wip] testing (#18)
* [[`c7465d7`](https://github.com/devsnek/snekfetch/commit/c7465d75fafa73710d9bb8067381388a2d99c1cf)] - update jsdoc-dynamic dep
* [[`7682983`](https://github.com/devsnek/snekfetch/commit/76829830b5cc58115935301bb1afd371734bed90)] - fix site
* [[`b66f988`](https://github.com/devsnek/snekfetch/commit/b66f988a40c7c21efdb565fe81de4630aa1c0218)] - clean up config
* [[`7672006`](https://github.com/devsnek/snekfetch/commit/76720066646502bd677759b9a667a74ed5146bb5)] - new docs
* [[`0f404fc`](https://github.com/devsnek/snekfetch/commit/0f404fc2f21e91be332843ef390f3834777035de)] - fix deps for http2 from npm
* [[`d66bdf2`](https://github.com/devsnek/snekfetch/commit/d66bdf21423d65b1b159ca2d24acabdd1016a2f0)] - remove M-SEARCH because method name doc issues and no one uses it
* [[`4d2f885`](https://github.com/devsnek/snekfetch/commit/4d2f885b1ee7d6ecaaf3418230728f412965d45a)] - update jsdoc-dynamic
* [[`76d9cbd`](https://github.com/devsnek/snekfetch/commit/76d9cbda468270b81c3306c9b490db5620054e59)] - Merge branch 'master' of https://github.com/devsnek/snekfetch
* [[`7aea2c8`](https://github.com/devsnek/snekfetch/commit/7aea2c82b19a99b97468321de1153fcbf6806564)] - update issue template
* [[`7372470`](https://github.com/devsnek/snekfetch/commit/73724709c7bcb732165f12503066ba86cd922198)] - fix content type bug
* [[`d089ab7`](https://github.com/devsnek/snekfetch/commit/d089ab751bfd447c7178081a9a8e92961c05b667)] - remove socket listeners
* [[`5081c2f`](https://github.com/devsnek/snekfetch/commit/5081c2f859baed1cc1cb56af7427c7116a0255ac)] - Release 3.4.3
* [[`fd610ec`](https://github.com/devsnek/snekfetch/commit/fd610ece2d8df60cf8bc1323c1b536cf1237d11e)] - handle socket errors in a way that only node could think of
* [[`e29c9f5`](https://github.com/devsnek/snekfetch/commit/e29c9f58cf6386c3e92c9a58597ac72260969efd)] - these are static
* [[`dad2b8d`](https://github.com/devsnek/snekfetch/commit/dad2b8d235f60ab785bdbdbb7665e623571a4cea)] - update jsdoc-dynamic dep
* [[`498fc92`](https://github.com/devsnek/snekfetch/commit/498fc92ba0c63370498bcd74e5fb6c4f609a122d)] - new doc stuff
* [[`328e9e6`](https://github.com/devsnek/snekfetch/commit/328e9e6bf148ed2198d70768a017bf528b16ce1f)] - update readme
* [[`9c8dd75`](https://github.com/devsnek/snekfetch/commit/9c8dd75f3c8bf8409b4781c99d5171e2075f7d77)] - damn gitignore oddities
* [[`5ee30b2`](https://github.com/devsnek/snekfetch/commit/5ee30b2242aa8e0fd0075bd148d94f0a078d00e1)] - switch theme
* [[`30695c7`](https://github.com/devsnek/snekfetch/commit/30695c74bc7732cb002e7e4e54b4b74426154e46)] - disable emails
* [[`1b969f8`](https://github.com/devsnek/snekfetch/commit/1b969f8b391aad7de6ddc7ccc5c7a10821d1cde8)] - Docsgen (#15)
* [[`7234c5a`](https://github.com/devsnek/snekfetch/commit/7234c5a446f53f4c93b8620822c5e3aa1dd6c5ff)] - remove unused file
* [[`f011cc0`](https://github.com/devsnek/snekfetch/commit/f011cc0d2236468ea9a61ba7f1a6fd9254d2ef0f)] - Release 3.4.2
* [[`9c2af2b`](https://github.com/devsnek/snekfetch/commit/9c2af2be6975d93c5015d5f29c1f7a53216234ec)] - Release 3.4.1
* [[`69a02ae`](https://github.com/devsnek/snekfetch/commit/69a02ae653f42e51b71334853df258e990a23894)] - http2 and form data fix
* [[`2aaae71`](https://github.com/devsnek/snekfetch/commit/2aaae71aef8064a7b5d1c254c0e4ae62b4f73348)] - http2 body works now
* [[`2bcc585`](https://github.com/devsnek/snekfetch/commit/2bcc585a7eaabfaa7f9a883796cfa92fe8f4ab1a)] - Merge branch 'master' of https://github.com/devsnek/snekfetch
* [[`3a99360`](https://github.com/devsnek/snekfetch/commit/3a99360357918b751f043266573450a421aee6eb)] - delete passthrough stream
* [[`e9addda`](https://github.com/devsnek/snekfetch/commit/e9addda1930529c112823a16dc90773df8756775)] - Update index.js
* [[`d625e43`](https://github.com/devsnek/snekfetch/commit/d625e4314ae7db6138cbbc5f37b7dfbeb8176986)] - bump version
* [[`c629c15`](https://github.com/devsnek/snekfetch/commit/c629c15fa0f0268b461cae137c2da7e90e3af956)] - don't allow agent if not following redirects
* [[`9e568db`](https://github.com/devsnek/snekfetch/commit/9e568db3a83e42f83ed9f9e19b0aac14b9e4e190)] - redirect stuff
* [[`68ee0f8`](https://github.com/devsnek/snekfetch/commit/68ee0f8774da5d55f23f231fc018c3836a343424)] - [fix/browser] redirect behavior
* [[`9b9c8d8`](https://github.com/devsnek/snekfetch/commit/9b9c8d84754f9c2867ce08b1a8cc43d4781b16c7)] - fix header object name
* [[`b555054`](https://github.com/devsnek/snekfetch/commit/b555054de419a8153f0450bfe31697df71edda25)] - fix version regression
* [[`ca8fd71`](https://github.com/devsnek/snekfetch/commit/ca8fd71bae0934b3e50637f7cdc4ddaf35522f37)] - change to rc for npm release
* [[`8eabe8f`](https://github.com/devsnek/snekfetch/commit/8eabe8f960736dca0dc4638562d02f3b947e13c1)] - clean up query handling
* [[`5438a11`](https://github.com/devsnek/snekfetch/commit/5438a11944112a14e7eed3819504dade13140d26)] - webpack magic half the build size
* [[`49b3bc7`](https://github.com/devsnek/snekfetch/commit/49b3bc728b6a4e4b04c3dd4ca8c83281e78834e3)] - finalize browser builds
* [[`b9081a5`](https://github.com/devsnek/snekfetch/commit/b9081a5933cb014eb067ff4e27935a9a1a9294b6)] - clean up
* [[`9c1d4b6`](https://github.com/devsnek/snekfetch/commit/9c1d4b6128dc37caa13fb20f3093e1bf4c5aa65b)] - fix up query and final headers
* [[`80f56f8`](https://github.com/devsnek/snekfetch/commit/80f56f86a7519d1ebed62161c796db2880c153f6)] - bump version
* [[`4c5cd25`](https://github.com/devsnek/snekfetch/commit/4c5cd25549bb36f00d12aef041f7167276fd54ee)] - update readme
* [[`6350e96`](https://github.com/devsnek/snekfetch/commit/6350e965b9a97659bd93f0a47eec65b6d224f359)] - remove dev build
* [[`97333e2`](https://github.com/devsnek/snekfetch/commit/97333e2354e977c23bd8b649bcafc1cbddff8e08)] - disable process shim in a hacky way
* [[`d4bf84a`](https://github.com/devsnek/snekfetch/commit/d4bf84a44e0f2cd7fd0da9c52ea692cdb552dd24)] - fix selector error
* [[`6296e7a`](https://github.com/devsnek/snekfetch/commit/6296e7a721c6a62ca67f1419b5de9e68b540f1c2)] - wow it works
* [[`568a1f3`](https://github.com/devsnek/snekfetch/commit/568a1f3206818862a2eea70b97192d93525fa2fd)] - begin rewrite
* [[`feba8ae`](https://github.com/devsnek/snekfetch/commit/feba8ae8ceed8a3bada13503e5a2cfd6a09ac4b4)] - begin rewrite
* [[`a7d2c68`](https://github.com/devsnek/snekfetch/commit/a7d2c68f09b873a0d663c1115de5b11d9d3273b7)] - fix stupid replace error
* [[`b379521`](https://github.com/devsnek/snekfetch/commit/b3795219bc3e67b94c30c072a84c381680e3416d)] - move exports around
* [[`13d6538`](https://github.com/devsnek/snekfetch/commit/13d65386217356e1da9a230233edf30f91011bab)] - remove FormData polyfill from webpack
* [[`a0b55c1`](https://github.com/devsnek/snekfetch/commit/a0b55c1fac15e333602b0fdc6b07fdf05e4e69c4)] - bump version
* [[`4307f7e`](https://github.com/devsnek/snekfetch/commit/4307f7ea7168c4b7f4f12bdf6114bb6cd89af2e2)] - fix webpack
* [[`9a67ea9`](https://github.com/devsnek/snekfetch/commit/9a67ea914a18f053a24a5a372df5690a5988a1b4)] - bump version
* [[`7b4fff6`](https://github.com/devsnek/snekfetch/commit/7b4fff64301580b46668d46e45a88fbd0330b055)] - Merge branch 'master' of https://github.com/devsnek/snekfetch
* [[`21549f7`](https://github.com/devsnek/snekfetch/commit/21549f7edb4a7ea8a6757a7e9322766fe0e5b131)] - fix more small bugs
* [[`434b096`](https://github.com/devsnek/snekfetch/commit/434b0964d75ad4f923e8a39219d5a41595226f99)] - Add license scan report and status (#7)
* [[`bca7b08`](https://github.com/devsnek/snekfetch/commit/bca7b089e562c2e5cdbd22fc62655e1fb5c3fa55)] - add intial http2 support
* [[`f27aa24`](https://github.com/devsnek/snekfetch/commit/f27aa2406a5eeeaec6aa12b478ed14c06e0081c2)] - bump version
* [[`a06e6f1`](https://github.com/devsnek/snekfetch/commit/a06e6f1b513f89ea34f06a4038077f5958abb25e)] - Fix Content-Length header (#6)
* [[`a02c170`](https://github.com/devsnek/snekfetch/commit/a02c170f3ba279d7962a7b0c63453648608bd0ae)] - fix mime buffer checking
* [[`050c91b`](https://github.com/devsnek/snekfetch/commit/050c91b0d170394789416a70b114ecafa247becd)] - fix form uploads
* [[`cf763fc`](https://github.com/devsnek/snekfetch/commit/cf763fcd64a30e4c8c63c84d8b28240119a62563)] - bump version
* [[`75b69ad`](https://github.com/devsnek/snekfetch/commit/75b69ad1f653c57d15d4cc4a68f4968a04e6c6f0)] - add handlers for buffers and streams
* [[`3501019`](https://github.com/devsnek/snekfetch/commit/35010194ea8824e075e96dd2b13e5b94c9b7ee0a)] - so much cool stuff
* [[`b0b160b`](https://github.com/devsnek/snekfetch/commit/b0b160bed114bcc9d71932eac8cbb741351e212c)] - add agent support
* [[`9143280`](https://github.com/devsnek/snekfetch/commit/9143280d1b5f504cf7e2fd4d7a38d359f3db3195)] - Delete .fileLoader.js.swp
* [[`139f09f`](https://github.com/devsnek/snekfetch/commit/139f09f32a670371f07cb78215eab9385d12f41e)] - fix stuff
* [[`5eeae29`](https://github.com/devsnek/snekfetch/commit/5eeae2934d5aeeabea18ef86729d534da696e392)] - Update index.js
* [[`038dada`](https://github.com/devsnek/snekfetch/commit/038dada4aba8ba74423faab20dc1b9768114a3a6)] - Disable Automatic Redirects (#5)
* [[`67f2366`](https://github.com/devsnek/snekfetch/commit/67f2366a6751585958e2a5ca58278edf5a7f21e6)] - help out rollup
* [[`eaf21ae`](https://github.com/devsnek/snekfetch/commit/eaf21ae15646177d7104e20d2b7902acb6e6fed2)] - fix mime bug
* [[`ae936f5`](https://github.com/devsnek/snekfetch/commit/ae936f50d748e77f82905f64ece925e00fdbbb3a)] - bump version
* [[`6f103c9`](https://github.com/devsnek/snekfetch/commit/6f103c9f5ad9037a412413687ddfb7f4557520c9)] - wowee 404s work now
* [[`6b6e8db`](https://github.com/devsnek/snekfetch/commit/6b6e8db679e63ca9f8db7d85202263977f48e922)] - development file read/write
* [[`adf8aa1`](https://github.com/devsnek/snekfetch/commit/adf8aa1b110336be981a2a6617b0469ac5705389)] - this should really be a buffer
* [[`df8d646`](https://github.com/devsnek/snekfetch/commit/df8d6468f608f5cdb5aac1b84a83ced3c1f5eeae)] - docs and lazy load res.body
* [[`f60812f`](https://github.com/devsnek/snekfetch/commit/f60812fe9de9cfa6e0329943e64e5166f926e19e)] - ugh
* [[`cd4bfd9`](https://github.com/devsnek/snekfetch/commit/cd4bfd91bae58076e7a2f210a1ff85d4295490b1)] - merge
* [[`befd0eb`](https://github.com/devsnek/snekfetch/commit/befd0ebaf97317ea888c5e62c7aa52b789d6a0c6)] - i dunno
* [[`1db6103`](https://github.com/devsnek/snekfetch/commit/1db6103ca263c5687ed318358fee863dbad5c2b7)] - fix a thing
* [[`35736c4`](https://github.com/devsnek/snekfetch/commit/35736c42c94fda9709401e31947e2c101fec1c0a)] - add docs
* [[`c5e03b1`](https://github.com/devsnek/snekfetch/commit/c5e03b1b0cf1c4434e82c3205f70ca24c26b5144)] - bump version
* [[`50400f5`](https://github.com/devsnek/snekfetch/commit/50400f50d15fed3f0373dfabecf0e31d4e5fef49)] - fix up checking if response is here
* [[`7c35045`](https://github.com/devsnek/snekfetch/commit/7c35045e9e9dd28bfc5e0a4ed55a3ba2e6d6ecd4)] - bump version
* [[`f47ae61`](https://github.com/devsnek/snekfetch/commit/f47ae6179addc843c76041a5b0a1013c67759729)] - fix stuff
* [[`498c722`](https://github.com/devsnek/snekfetch/commit/498c722dd86ac6428e92a8f490a2d5ad07542853)] - Update package.json
* [[`9830b16`](https://github.com/devsnek/snekfetch/commit/9830b165c395c17b055e0d2c45704209a09ed904)] - fix redirecting
* [[`b03a6bb`](https://github.com/devsnek/snekfetch/commit/b03a6bb7d3b73ac3a4b27c7cfffcfbaa87d38700)] - fix extname
* [[`9b5f0bc`](https://github.com/devsnek/snekfetch/commit/9b5f0bc9700e5d2fc03bc2cdae9e6494d45e6dcd)] - Create PULL_REQUEST_TEMPLATE.md
* [[`37f0341`](https://github.com/devsnek/snekfetch/commit/37f03415473ccc52436590d4741dce40fc49d526)] - Create ISSUE_TEMPLATE.md
* [[`6679e13`](https://github.com/devsnek/snekfetch/commit/6679e138e66f50b3843ba207fc5b0dda1bc76e95)] - friggin stupid issues https://github.com/jhiesey/stream-http/pull/77
* [[`8608de3`](https://github.com/devsnek/snekfetch/commit/8608de3d1af3e8eec3c9a36b710dca72e572a728)] - disable sync
* [[`43e2312`](https://github.com/devsnek/snekfetch/commit/43e23127bb29b5660e04c2431a5c5f3cfc8d9f24)] - this is so unprofessional
* [[`88a2f7e`](https://github.com/devsnek/snekfetch/commit/88a2f7e9d5b319136c92f91fc4e07fe248c91b5f)] - i really hate working with mock libs
* [[`a79f686`](https://github.com/devsnek/snekfetch/commit/a79f6867d21ca58ffe6fc59eb77b06f257f8ad29)] - Update package.json
* [[`8c881ca`](https://github.com/devsnek/snekfetch/commit/8c881ca030ccc67d3dd40c247a85971654279991)] - i hate myself
* [[`e4c9d25`](https://github.com/devsnek/snekfetch/commit/e4c9d25d7da9293f0800b833dc702e1b15ac072e)] - i really shouldn't use webeditor
* [[`e6a467d`](https://github.com/devsnek/snekfetch/commit/e6a467d6d0798873eb0312c0d586b88373dfd2c2)] - Change read() back to _read()
* [[`25647d1`](https://github.com/devsnek/snekfetch/commit/25647d1c4dfbc57198853d5ebc17a01bbea3dd09)] - Fix breaking .getHeader typo
* [[`8a8b2eb`](https://github.com/devsnek/snekfetch/commit/8a8b2eba604450363bf80e8e0caac97157f15820)] - Update package.json
* [[`d6d7364`](https://github.com/devsnek/snekfetch/commit/d6d7364438ce034040655a80e3edb6f0f20ea669)] - Update index.js
* [[`fa1566c`](https://github.com/devsnek/snekfetch/commit/fa1566c04831fa7272e01dff8936e1f5d467dc6b)] - Update index.js
* [[`89ee801`](https://github.com/devsnek/snekfetch/commit/89ee801ae233177b8cbca8e1fd02cd9915264e2b)] - bump version
* [[`0f2f25e`](https://github.com/devsnek/snekfetch/commit/0f2f25e2620de84e41b2ab0465a73af87b3471f2)] - make send smarter
* [[`24077d8`](https://github.com/devsnek/snekfetch/commit/24077d847f1ddf6149c8ae9ce1448f046c94946b)] - optimize
* [[`f94a195`](https://github.com/devsnek/snekfetch/commit/f94a195dc1048a249858a234b691073543172d3b)] - bump to 3.0.3
* [[`06a7a0e`](https://github.com/devsnek/snekfetch/commit/06a7a0ee1e994bae5947faef6730b5607f5e18b0)] - all sorts of cleanup
* [[`1eb5225`](https://github.com/devsnek/snekfetch/commit/1eb52253daa176a2391fc8aab329e7b095f46671)] - better query
* [[`a2dbe10`](https://github.com/devsnek/snekfetch/commit/a2dbe10b308f9d9ffad8debac3f83bab37c1de8a)] - query
* [[`224554f`](https://github.com/devsnek/snekfetch/commit/224554f658db6489deb253b327fbaa53d839c2ca)] - rip
* [[`ebf0c31`](https://github.com/devsnek/snekfetch/commit/ebf0c310c8e1d5c72ec1c1447b0b06b0c868de55)] - remove timeout
* [[`71fa23a`](https://github.com/devsnek/snekfetch/commit/71fa23aec96a4a40ce6acca2ed104db20308c8e6)] - add timeout
* [[`8a54efd`](https://github.com/devsnek/snekfetch/commit/8a54efdb43c46fddea69d83a7b0361f2f59fa7bb)] - fix extremely stupid mistake
* [[`572e34c`](https://github.com/devsnek/snekfetch/commit/572e34c14bd1b78a6287091cfc54784d49a90dc9)] - bump to 3.0.1
* [[`6073d6c`](https://github.com/devsnek/snekfetch/commit/6073d6cbc847dfc3e2f0667b9bd5dc4e1aba7348)] - standardize methods, properly emit errors when piping
* [[`63a0abb`](https://github.com/devsnek/snekfetch/commit/63a0abb0a5863e6cbb19919eb7f5438b8711e142)] - add sync requests for memes not real usage
* [[`390f8f4`](https://github.com/devsnek/snekfetch/commit/390f8f49f0300924fb12ada247c6ff8b1133df5d)] - add sync requests for memes not real usage
* [[`50ae37a`](https://github.com/devsnek/snekfetch/commit/50ae37a558c1dd1b8a345e299a5f23a8987bc9e4)] - add sync requests for memes not real usage
* [[`dd0c84b`](https://github.com/devsnek/snekfetch/commit/dd0c84becf244f4b5157c3874a1f8812ef714c78)] - v3